package com.pp1.parkingfinder.model;

public class LeaserTest {
}
