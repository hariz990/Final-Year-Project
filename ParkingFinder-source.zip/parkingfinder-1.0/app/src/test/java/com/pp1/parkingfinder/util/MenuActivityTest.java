package com.pp1.parkingfinder.util;

import org.junit.Test;

public class MenuActivityTest {

    @Test
    public void onCreate() {
    }
}