package com.pp1.parkingfinder.view;

import org.junit.Test;

public class RegistrationActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onCreate1() {
    }
}