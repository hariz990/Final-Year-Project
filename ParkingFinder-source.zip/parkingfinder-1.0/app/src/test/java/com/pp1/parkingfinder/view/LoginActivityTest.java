package com.pp1.parkingfinder.view;

import org.junit.Test;

public class LoginActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void showProgressingView() {
    }

    @Test
    public void hideProgressingView() {
    }
}