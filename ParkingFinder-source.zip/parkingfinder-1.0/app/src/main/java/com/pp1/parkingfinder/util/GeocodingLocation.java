package com.pp1.parkingfinder.util;

/*
Creates thread to handle Geocodingconversion of address input into lat:lon coordinates.
 */
public class GeocodingLocation {

    private static final String TAG = "GeocodingLocation";

}